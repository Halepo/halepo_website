<footer class="footer py-5 text-center">
	<div class="container">
		<div class="row mb-5">
			<div class="col-12">
				<p class="mb-0">
					<a href="#" class="p-3"><span class="icon-facebook"></span></a>
					<a href="#" class="p-3"><span class="icon-twitter"></span></a>
					<a href="#" class="p-3"><span class="icon-instagram"></span></a>
					<a href="#" class="p-3"><span class="icon-linkedin"></span></a>
					<a href="#" class="p-3"><span class="icon-pinterest"></span></a>
				</p>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<p class="mb-0">
					Copyright &copy;
					<script>
						document.write(new Date().getFullYear());
					</script>
					All rights reserved | This template is made with
					<i class="icon-heart text-danger" aria-hidden="true"></i> by
					<a href="https://colorlib.com" target="_blank">Colorlib</a>
				</p>
			</div>
		</div>
	</div>
</footer>