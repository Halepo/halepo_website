<?php
/**
 * Show the excerpt.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage HaLePo
 * @since HaLePo WP 1.0
 */

the_excerpt();
