<?php
/**
 * Displays the post header
 *
 * @package WordPress
 * @subpackage HaLePo
 * @since HaLePo WP 1.0
 */

the_title( '<h1 class="entry-title">', '</h1>' );
